import sys
from collections import defaultdict

def main():
    data = sys.stdin.read().split()
    n, k = int(data[0]), int(data[1])
    seen = defaultdict(int)
    seen[0] = 1
    pre = ans = 0
    for x in map(int, data[2:2 + n]):
        pre += x
        ans += seen[pre - k]
        seen[pre] += 1
    print(ans)

main()
