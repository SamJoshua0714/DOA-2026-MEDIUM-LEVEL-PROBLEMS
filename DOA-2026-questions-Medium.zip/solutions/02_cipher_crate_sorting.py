import sys
from collections import Counter

def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    groups = Counter("".join(sorted(w)) for w in data[1:1 + n])
    print(len(groups), max(groups.values()))

main()
