import sys

def main():
    data = sys.stdin.read().split()
    m, n = int(data[0]), int(data[1])
    g = [data[2 + i * n: 2 + (i + 1) * n] for i in range(m)]
    seen = [[False] * n for _ in range(m)]
    count = best = 0
    for i in range(m):
        for j in range(n):
            if g[i][j] == "1" and not seen[i][j]:
                count += 1
                seen[i][j] = True
                stack, area = [(i, j)], 0
                while stack:
                    x, y = stack.pop()
                    area += 1
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        a, b = x + dx, y + dy
                        if 0 <= a < m and 0 <= b < n and g[a][b] == "1" and not seen[a][b]:
                            seen[a][b] = True
                            stack.append((a, b))
                best = max(best, area)
    print(count, best)

main()
