import sys

def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    iv = sorted((int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n))
    merged = [list(iv[0])]
    for l, r in iv[1:]:
        if l <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], r)
        else:
            merged.append([l, r])
    print(len(merged), sum(r - l + 1 for l, r in merged))

main()
