import sys
from collections import deque

def main():
    data = sys.stdin.read().split()
    m, n = int(data[0]), int(data[1])
    g = [list(map(int, data[2 + i * n: 2 + (i + 1) * n])) for i in range(m)]
    q = deque()
    healthy = 0
    for i in range(m):
        for j in range(n):
            if g[i][j] == 2:
                q.append((i, j, 0))
            elif g[i][j] == 1:
                healthy += 1
    t = 0
    while q:
        x, y, t = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            a, b = x + dx, y + dy
            if 0 <= a < m and 0 <= b < n and g[a][b] == 1:
                g[a][b] = 2
                healthy -= 1
                q.append((a, b, t + 1))
    print(t if healthy == 0 else -1)

main()
