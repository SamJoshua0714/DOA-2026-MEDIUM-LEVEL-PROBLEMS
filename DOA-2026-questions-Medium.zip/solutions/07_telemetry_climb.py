import sys

MOD = 1_000_000_007

def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    a = list(map(int, data[1:1 + n]))
    length = [1] * n
    cnt = [1] * n
    for i in range(n):
        for j in range(i):
            if a[j] < a[i]:
                if length[j] + 1 > length[i]:
                    length[i] = length[j] + 1
                    cnt[i] = cnt[j]
                elif length[j] + 1 == length[i]:
                    cnt[i] = (cnt[i] + cnt[j]) % MOD
    best = max(length)
    print(best, sum(c for l, c in zip(length, cnt) if l == best) % MOD)

main()
