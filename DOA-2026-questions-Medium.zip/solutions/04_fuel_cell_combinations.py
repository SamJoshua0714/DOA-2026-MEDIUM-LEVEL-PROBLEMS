import sys

MOD = 1_000_000_007

def main():
    data = sys.stdin.read().split()
    n, t = int(data[0]), int(data[1])
    coins = list(map(int, data[2:2 + n]))
    INF = float("inf")
    mn = [INF] * (t + 1)
    ways = [0] * (t + 1)
    mn[0] = 0
    ways[0] = 1
    for c in coins:
        for v in range(c, t + 1):
            if mn[v - c] + 1 < mn[v]:
                mn[v] = mn[v - c] + 1
            ways[v] = (ways[v] + ways[v - c]) % MOD
    if mn[t] == INF:
        print("-1 0")
    else:
        print(mn[t], ways[t])

main()
