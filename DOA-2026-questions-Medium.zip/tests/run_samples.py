import json, subprocess, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
tests = json.load(open(root / "tests" / "samples.json"))
bad = 0
for t in tests:
    r = subprocess.run([sys.executable, str(root / "solutions" / f"{t['problem']}.py")],
                       input=t["input"] + "\n", capture_output=True, text=True)
    if r.stdout.strip() != t["output"]:
        bad += 1
        print(f"FAIL {t['problem']}: expected {t['output']!r}, got {r.stdout.strip()!r}")
print(f"{len(tests) - bad}/{len(tests)} samples passed")
sys.exit(bad)
